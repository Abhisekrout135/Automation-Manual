package Practice_programing;

public class ODDno {

	public static void main(String[] args) {
		

	}

}
