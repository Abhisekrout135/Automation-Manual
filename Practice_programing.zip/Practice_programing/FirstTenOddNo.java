package Practice_programing;

public class FirstTenOddNo {

	public static void main(String[] args) {
		        int count = 0;
		        int number = 1;

		        while (count < 10) {
		            System.out.print(number + " ");
		            number += 2;
		            count++;
		        }
		    }
		

	}


